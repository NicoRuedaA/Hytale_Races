package NicoRueda.ui;

import com.hypixel.hytale.protocol.packets.interface_.CustomPageLifetime;
import com.hypixel.hytale.server.core.entity.entities.player.pages.BasicCustomUIPage;
import com.hypixel.hytale.server.core.ui.builder.UICommandBuilder;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import javax.annotation.Nonnull;

public class RaceEmptyPage extends BasicCustomUIPage {
    public RaceEmptyPage(@Nonnull PlayerRef playerRef) {
        super(playerRef, CustomPageLifetime.CanDismiss);
    }

    @Override
    public void build(@Nonnull UICommandBuilder commandBuilder) {
        commandBuilder.appendInline(
                null,
                "Group #Root {"
                        + " Anchor: (Full: 0);"
                        + " Background: #000000(0.35);"
                        + " LayoutMode: CenterMiddle;"
                        + " Group #Window {"
                        + "  Anchor: (Width: 420, Height: 220);"
                        + "  Background: #111111(0.9);"
                        + "  Padding: (Full: 16);"
                        + "  LayoutMode: CenterMiddle;"
                        + "  Label #Title {"
                        + "   Text: \"UI de prueba\";"
                        + "   Style: (FontSize: 20, HorizontalAlignment: Center);"
                        + "  }"
                        + " }"
                        + "}");
    }
}
