/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.server.core.command.system.AbstractCommand
 *  com.hypixel.hytale.server.core.command.system.basecommands.AbstractCommandCollection
 */
package NicoRueda.commands;

import com.hypixel.hytale.server.core.command.system.AbstractCommand;
import com.hypixel.hytale.server.core.command.system.basecommands.AbstractCommandCollection;

public class PlayableRacesPluginCommand
        extends AbstractCommandCollection {
    public PlayableRacesPluginCommand() {
        super("race", "Comandos de PlayableRaces");
        this.addSubCommand((AbstractCommand) new HelpSubCommand());
        this.addSubCommand((AbstractCommand) new RaceCommand.UiSubCommand());
        this.addSubCommand((AbstractCommand) new RaceCommand.ChangeSubCommand());
        this.addSubCommand((AbstractCommand) new RaceCommand.InfoRaceSubCommand());
        this.addSubCommand((AbstractCommand) new RaceCommand.ResetSubCommand());
        this.addSubCommand((AbstractCommand) new RaceCommand.ListSubCommand());
    }

    protected boolean canGeneratePermission() {
        return false;
    }
}
