/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.server.core.command.system.CommandContext
 *  com.hypixel.hytale.server.core.command.system.basecommands.CommandBase
 *  javax.annotation.Nonnull
 */
package NicoRueda.commands;

import com.hypixel.hytale.server.core.Message;
import com.hypixel.hytale.server.core.command.system.CommandContext;
import com.hypixel.hytale.server.core.command.system.basecommands.CommandBase;
import javax.annotation.Nonnull;

public class HelpSubCommand
        extends CommandBase {
    public HelpSubCommand() {
        super("help", "Muestra los comandos disponibles");
        this.setPermissionGroup(null);
    }

    protected boolean canGeneratePermission() {
        return false;
    }

    protected void executeSync(@Nonnull CommandContext context) {
        context.sendMessage(Message.raw("=== Comandos de razas ==="));
        context.sendMessage(Message.raw("/race help - Muestra esta ayuda"));
        context.sendMessage(Message.raw("/race ui - Abre una ventana UI vacía de prueba"));
        context.sendMessage(Message.raw("/race list - Lista las razas disponibles"));
        context.sendMessage(Message.raw("/race change <raza> - Cambia tu raza"));
        context.sendMessage(Message.raw("/race info - Muestra tu raza actual"));
        context.sendMessage(Message.raw("/race reset - Borra tu raza actual"));
        context.sendMessage(Message.raw("========================="));
    }
}
