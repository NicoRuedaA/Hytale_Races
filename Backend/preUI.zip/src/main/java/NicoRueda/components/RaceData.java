/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.codec.Codec
 *  com.hypixel.hytale.codec.KeyedCodec
 *  com.hypixel.hytale.codec.builder.BuilderCodec
 *  com.hypixel.hytale.codec.builder.BuilderCodec$Builder
 *  com.hypixel.hytale.component.Component
 *  com.hypixel.hytale.server.core.universe.world.storage.EntityStore
 */
package NicoRueda.components;

import com.hypixel.hytale.codec.Codec;
import com.hypixel.hytale.codec.KeyedCodec;
import com.hypixel.hytale.codec.builder.BuilderCodec;
import com.hypixel.hytale.component.Component;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;

public class RaceData
implements Component<EntityStore> {
    private String selectedRace = null;
    public static final BuilderCodec<RaceData> CODEC = ((BuilderCodec.Builder)BuilderCodec.builder(RaceData.class, RaceData::new).append(new KeyedCodec("SelectedRace", (Codec)Codec.STRING), RaceData::setSelectedRace, RaceData::getSelectedRace).add()).build();

    public String getSelectedRace() {
        return this.selectedRace;
    }

    public void setSelectedRace(String raceId) {
        this.selectedRace = raceId;
    }

    public boolean hasRace() {
        return this.selectedRace != null && !this.selectedRace.isEmpty();
    }

    public Component<EntityStore> clone() {
        RaceData copy = new RaceData();
        copy.selectedRace = this.selectedRace;
        return copy;
    }

    public String toString() {
        return "RaceData{selectedRace='" + this.selectedRace + "'}";
    }
}

