/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.codec.Codec
 *  com.hypixel.hytale.codec.KeyedCodec
 *  com.hypixel.hytale.codec.builder.BuilderCodec
 *  com.hypixel.hytale.codec.builder.BuilderCodec$Builder
 *  com.hypixel.hytale.component.Component
 *  com.hypixel.hytale.component.ComponentType
 *  com.hypixel.hytale.server.core.universe.world.storage.EntityStore
 */
package NicoRueda.components;

import com.hypixel.hytale.codec.Codec;
import com.hypixel.hytale.codec.KeyedCodec;
import com.hypixel.hytale.codec.builder.BuilderCodec;
import com.hypixel.hytale.component.Component;
import com.hypixel.hytale.component.ComponentType;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;

public class RaceStatTracker
implements Component<EntityStore> {
    private static ComponentType<EntityStore, RaceStatTracker> componentType;
    private float lastHealth = -1.0f;
    private float lastMana = -1.0f;
    private float lastStamina = -1.0f;
    private float pendingPoisonHeal = 0.0f;
    private int respawnGraceTicks = 0;
    public static final BuilderCodec<RaceStatTracker> CODEC;

    public static void setComponentType(ComponentType<EntityStore, RaceStatTracker> type) {
        componentType = type;
    }

    public static ComponentType<EntityStore, RaceStatTracker> getComponentType() {
        return componentType;
    }

    public float getLastHealth() {
        return this.lastHealth;
    }

    public void setLastHealth(float lastHealth) {
        this.lastHealth = lastHealth;
    }

    public float getLastMana() {
        return this.lastMana;
    }

    public void setLastMana(float lastMana) {
        this.lastMana = lastMana;
    }

    public float getLastStamina() {
        return this.lastStamina;
    }

    public void setLastStamina(float lastStamina) {
        this.lastStamina = lastStamina;
    }

    public float getPendingPoisonHeal() {
        return this.pendingPoisonHeal;
    }

    public void setPendingPoisonHeal(float pendingPoisonHeal) {
        this.pendingPoisonHeal = pendingPoisonHeal;
    }

    public void addPendingPoisonHeal(float amount) {
        if (amount <= 0.0f) {
            return;
        }
        this.pendingPoisonHeal += amount;
    }

    public float consumePendingPoisonHeal(float amount) {
        if (amount <= 0.0f || this.pendingPoisonHeal <= 0.0f) {
            return 0.0f;
        }
        float consumed = Math.min(this.pendingPoisonHeal, amount);
        this.pendingPoisonHeal -= consumed;
        return consumed;
    }

    public int getRespawnGraceTicks() {
        return this.respawnGraceTicks;
    }

    public void setRespawnGraceTicks(int ticks) {
        this.respawnGraceTicks = ticks;
    }

    public void decrementRespawnGrace() {
        if (this.respawnGraceTicks > 0) {
            --this.respawnGraceTicks;
        }
    }

    public Component<EntityStore> clone() {
        RaceStatTracker copy = new RaceStatTracker();
        copy.lastHealth = this.lastHealth;
        copy.lastMana = this.lastMana;
        copy.lastStamina = this.lastStamina;
        copy.pendingPoisonHeal = this.pendingPoisonHeal;
        copy.respawnGraceTicks = this.respawnGraceTicks;
        return copy;
    }

    static {
        CODEC = BuilderCodec.builder(RaceStatTracker.class, RaceStatTracker::new)
            .<Float>append(new KeyedCodec<>("LastHealth", Codec.FLOAT), RaceStatTracker::setLastHealth, RaceStatTracker::getLastHealth)
            .add()
            .<Float>append(new KeyedCodec<>("LastMana", Codec.FLOAT), RaceStatTracker::setLastMana, RaceStatTracker::getLastMana)
            .add()
            .<Float>append(new KeyedCodec<>("LastStamina", Codec.FLOAT), RaceStatTracker::setLastStamina, RaceStatTracker::getLastStamina)
            .add()
            .<Float>append(new KeyedCodec<>("PendingPoisonHeal", Codec.FLOAT), RaceStatTracker::setPendingPoisonHeal, RaceStatTracker::getPendingPoisonHeal)
            .add()
            .<Integer>append(new KeyedCodec<>("RespawnGraceTicks", Codec.INTEGER), RaceStatTracker::setRespawnGraceTicks, RaceStatTracker::getRespawnGraceTicks)
            .add()
            .build();
    }
}

