package NicoRueda;

import NicoRueda.commands.PlayableRacesPluginCommand;
import NicoRueda.components.RaceData;
import NicoRueda.components.RaceStatTracker;
import NicoRueda.listeners.PlayerListener;
import NicoRueda.races.AmphibianRace;
import NicoRueda.races.BeastRace;
import NicoRueda.races.EldritchRace;
import NicoRueda.races.HumanRace;
import NicoRueda.races.MonsterRace;
import NicoRueda.races.RaceRegistry;
import NicoRueda.races.UndeadRace;
import NicoRueda.systems.EldritchManaInterceptionSystem;
import NicoRueda.systems.MonsterBleedOnHitSystem;
import NicoRueda.systems.RaceStatModifierSystem;
import NicoRueda.systems.UndeadHealingInversionSystem;
import NicoRueda.systems.UndeadPoisonHealingSystem;
import com.hypixel.hytale.component.ComponentType;
import com.hypixel.hytale.component.system.ISystem;
import com.hypixel.hytale.event.EventRegistry;
import com.hypixel.hytale.logger.HytaleLogger;
import com.hypixel.hytale.server.core.Message;
import com.hypixel.hytale.server.core.command.system.AbstractCommand;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.event.events.player.PlayerReadyEvent;
import com.hypixel.hytale.server.core.plugin.JavaPlugin;
import com.hypixel.hytale.server.core.plugin.JavaPluginInit;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import java.util.logging.Level;
import javax.annotation.Nonnull;

public class PlayableRacesPlugin
extends JavaPlugin {
    private static final HytaleLogger LOGGER = HytaleLogger.forEnclosingClass();
    private static PlayableRacesPlugin instance;

    public PlayableRacesPlugin(@Nonnull JavaPluginInit init) {
        super(init);
        instance = this;
    }

    public static PlayableRacesPlugin getInstance() {
        return instance;
    }

    protected void setup() {
        LOGGER.at(Level.INFO).log("[PlayableRaces] Iniciando setup...");
        this.registerRaces();
        this.registerRaceDataComponent();
        this.registerRaceStatTrackerComponent();
        this.registerCommands();
        this.registerListeners();
        LOGGER.at(Level.INFO).log("[PlayableRaces] Setup completado.");
    }

    protected void start() {
        this.registerSystems();
        LOGGER.at(Level.INFO).log("[PlayableRaces] Iniciado. Usa /race help para ver los comandos.");
    }

    protected void shutdown() {
        LOGGER.at(Level.INFO).log("[PlayableRaces] Cerrando...");
        RaceRegistry.clear();
        instance = null;
    }

    private void registerRaceStatTrackerComponent() {
        try {
            ComponentType trackerType = this.getEntityStoreRegistry().registerComponent(RaceStatTracker.class, "RaceStatTracker", RaceStatTracker.CODEC);
            RaceStatTracker.setComponentType((ComponentType<EntityStore, RaceStatTracker>)trackerType);
            LOGGER.at(Level.INFO).log("[PlayableRaces] Componente RaceStatTracker registrado.");
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error registrando RaceStatTracker.");
        }
    }

    private void registerRaces() {
        RaceRegistry.register(new HumanRace());
        RaceRegistry.register(new EldritchRace());
        RaceRegistry.register(new AmphibianRace());
        RaceRegistry.register(new BeastRace());
        RaceRegistry.register(new MonsterRace());
        RaceRegistry.register(new UndeadRace());
        LOGGER.at(Level.INFO).log("[PlayableRaces] %d razas registradas.", RaceRegistry.all().size());
    }

    private void registerRaceDataComponent() {
        try {
            ComponentType raceDataType = this.getEntityStoreRegistry().registerComponent(RaceData.class, "RaceData", RaceData.CODEC);
            RaceManager.setRaceDataType((ComponentType<EntityStore, RaceData>)raceDataType);
            LOGGER.at(Level.INFO).log("[PlayableRaces] Componente RaceData registrado.");
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.SEVERE).withCause((Throwable)e)).log("[PlayableRaces] Error registrando RaceData.");
        }
    }

    private void registerCommands() {
        try {
            this.getCommandRegistry().registerCommand((AbstractCommand)new PlayableRacesPluginCommand());
            LOGGER.at(Level.INFO).log("[PlayableRaces] Comando /race registrado.");
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error registrando comandos.");
        }
    }

    private void registerSystems() {
        try {
            this.getEntityStoreRegistry().registerSystem((ISystem)new UndeadPoisonHealingSystem());
            LOGGER.at(Level.INFO).log("[PlayableRaces] Sistema undead poison-heal registrado.");
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error registrando sistema undead poison-heal.");
        }
        try {
            this.getEntityStoreRegistry().registerSystem((ISystem)new UndeadHealingInversionSystem(RaceStatTracker.getComponentType()));
            LOGGER.at(Level.INFO).log("[PlayableRaces] Sistema undead healing inversion registrado.");
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error registrando sistema undead healing inversion.");
        }
        try {
            this.getEntityStoreRegistry().registerSystem((ISystem)new MonsterBleedOnHitSystem());
            LOGGER.at(Level.INFO).log("[PlayableRaces] Sistema monster bleed registrado.");
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error registrando sistema monster bleed.");
        }
        try {
            this.getEntityStoreRegistry().registerSystem((ISystem)new RaceStatModifierSystem(RaceStatTracker.getComponentType()));
            LOGGER.at(Level.INFO).log("[PlayableRaces] Sistema de stats de razas registrado.");
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error registrando sistema de stats de razas.");
        }
        try {
            this.getEntityStoreRegistry().registerSystem((ISystem)new EldritchManaInterceptionSystem(RaceManager.getRaceDataType(), RaceStatTracker.getComponentType()));
            LOGGER.at(Level.INFO).log("[PlayableRaces] Sistema Eldritch mana interception registrado.");
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error registrando sistema Eldritch mana interception.");
        }
    }

    private void registerListeners() {
        EventRegistry eventBus = this.getEventRegistry();
        try {
            new PlayerListener().register(eventBus);
            LOGGER.at(Level.INFO).log("[PlayableRaces] Listeners de jugador registrados.");
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error registrando PlayerListener.");
        }
        try {
            eventBus.registerGlobal(PlayerReadyEvent.class, this::onPlayerReady);
            LOGGER.at(Level.INFO).log("[PlayableRaces] Listener PlayerReadyEvent registrado.");
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error registrando PlayerReadyEvent.");
        }
    }

    private void onPlayerReady(PlayerReadyEvent event) {
        Player player = event.getPlayer();
        if (player == null) {
            return;
        }
        String raceId = RaceManager.getPlayerRace(player);
        if (raceId != null) {
            RaceManager.reapplyStats(player, raceId);
            player.sendMessage(Message.raw("Tu raza actual es: " + raceId));
        } else {
            player.sendMessage(Message.raw("No tienes raza seleccionada. Usa /race help para comenzar."));
        }
    }
}

