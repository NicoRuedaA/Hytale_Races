/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.component.Component
 *  com.hypixel.hytale.component.ComponentType
 *  com.hypixel.hytale.component.Ref
 *  com.hypixel.hytale.component.Store
 *  com.hypixel.hytale.server.core.entity.entities.Player
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 *  com.hypixel.hytale.server.core.universe.world.storage.EntityStore
 */
package NicoRueda;

import NicoRueda.components.RaceData;
import NicoRueda.races.RaceDefinition;
import NicoRueda.races.RaceRegistry;
import com.hypixel.hytale.component.Component;
import com.hypixel.hytale.component.ComponentType;
import com.hypixel.hytale.component.Ref;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.logger.HytaleLogger;
import com.hypixel.hytale.server.core.Message;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import java.util.logging.Level;

public final class RaceManager {
    private static final HytaleLogger LOGGER = HytaleLogger.forEnclosingClass();
    private static ComponentType<EntityStore, RaceData> raceDataType;
    private static final String RACE_MODIFIER_KEY = "playableraces_race_bonus";

    private RaceManager() {
    }

    public static void setRaceDataType(ComponentType<EntityStore, RaceData> type) {
        raceDataType = type;
    }

    public static ComponentType<EntityStore, RaceData> getRaceDataType() {
        return raceDataType;
    }

    public static void selectRace(Player player, String newRaceId) {
        if (player == null || newRaceId == null || raceDataType == null) {
            return;
        }
        RaceDefinition newRace = RaceRegistry.get(newRaceId);
        if (newRace == null) {
            player.sendMessage(Message.raw("Raza no encontrada: " + newRaceId));
            return;
        }
        Ref ref = player.getReference();
        if (ref == null || !ref.isValid()) {
            return;
        }
        try {
            RaceDefinition oldRace;
            Store store = ref.getStore();
            EntityStatMap stats = (EntityStatMap)store.getComponent(ref, EntityStatMap.getComponentType());
            RaceData data = (RaceData)store.getComponent(ref, raceDataType);
            if (data == null) {
                data = new RaceData();
            }
            if (data.hasRace() && data.getSelectedRace().equalsIgnoreCase(newRaceId)) {
                player.sendMessage(Message.raw("Ya tienes seleccionada la raza: " + newRace.displayName()));
                return;
            }
            if (data.hasRace() && stats != null && (oldRace = RaceRegistry.get(data.getSelectedRace())) != null) {
                oldRace.removeStats(stats, RACE_MODIFIER_KEY);
            }
            data.setSelectedRace(newRaceId);
            store.putComponent(ref, raceDataType, (Component)data);
            if (stats != null) {
                newRace.applyStats(stats, RACE_MODIFIER_KEY);
                stats.update();
            }
            LOGGER.at(Level.INFO).log("[PlayableRaces] Raza cambiada a: %s (%s)", (Object)newRace.displayName(), (Object)player.getDisplayName());
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error cambiando raza para %s", (Object)player.getDisplayName());
            player.sendMessage(Message.raw("Ocurrió un error interno al cambiar de raza."));
        }
    }

    public static String getPlayerRace(Player player) {
        if (player == null || raceDataType == null) {
            return null;
        }
        Ref ref = player.getReference();
        if (ref == null || !ref.isValid()) {
            return null;
        }
        try {
            RaceData data = (RaceData)ref.getStore().getComponent(ref, raceDataType);
            return data != null && data.hasRace() ? data.getSelectedRace() : null;
        }
        catch (Exception e) {
            return null;
        }
    }

    public static boolean hasRace(Player player) {
        return RaceManager.getPlayerRace(player) != null;
    }

    public static void reapplyStats(Player player, String raceId) {
        if (player == null || raceDataType == null) {
            return;
        }
        RaceDefinition race = RaceRegistry.get(raceId);
        if (race == null) {
            return;
        }
        Ref ref = player.getReference();
        if (ref == null || !ref.isValid()) {
            return;
        }
        try {
            Store store = ref.getStore();
            EntityStatMap stats = (EntityStatMap)store.getComponent(ref, EntityStatMap.getComponentType());
            if (stats != null) {
                race.applyStats(stats, RACE_MODIFIER_KEY);
                stats.update();
            }
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error re-aplicando stats al login para %s", (Object)player.getDisplayName());
        }
    }

    public static void resetRace(Player player) {
        if (player == null || raceDataType == null) {
            return;
        }
        Ref ref = player.getReference();
        if (ref == null || !ref.isValid()) {
            return;
        }
        try {
            RaceDefinition currentRace;
            Store store = ref.getStore();
            EntityStatMap stats = (EntityStatMap)store.getComponent(ref, EntityStatMap.getComponentType());
            RaceData data = (RaceData)store.getComponent(ref, raceDataType);
            if (data != null && data.hasRace() && stats != null && (currentRace = RaceRegistry.get(data.getSelectedRace())) != null) {
                currentRace.removeStats(stats, RACE_MODIFIER_KEY);
                stats.update();
            }
            store.putComponent(ref, raceDataType, (Component)new RaceData());
            LOGGER.at(Level.INFO).log("[PlayableRaces] Raza reseteada para %s", (Object)player.getDisplayName());
        }
        catch (Exception e) {
            ((HytaleLogger.Api)LOGGER.at(Level.WARNING).withCause((Throwable)e)).log("[PlayableRaces] Error reseteando raza para %s", (Object)player.getDisplayName());
        }
    }
}

