/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes
 */
package NicoRueda.races;

import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;
import com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes;

public class EldritchRace
implements RaceDefinition {
    @Override
    public String id() {
        return "eldritch";
    }

    @Override
    public String displayName() {
        return "Eldritch";
    }

    @Override
    public String tagline() {
        return "Poder arcano sin coste de man\u00e1. Conviertes tu vida en energ\u00eda.";
    }

    @Override
    public void applyStats(EntityStatMap stats, String modifierKey) {
        int healthId = DefaultEntityStatTypes.getHealth();
    }

    @Override
    public void removeStats(EntityStatMap stats, String modifierKey) {
        int healthId = DefaultEntityStatTypes.getHealth();
        stats.removeModifier(healthId, modifierKey);
    }
}

