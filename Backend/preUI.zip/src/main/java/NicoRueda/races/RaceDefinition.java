/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 */
package NicoRueda.races;

import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;

public interface RaceDefinition {
    public String id();

    public String displayName();

    public String tagline();

    public void applyStats(EntityStatMap var1, String var2);

    public void removeStats(EntityStatMap var1, String var2);
}

