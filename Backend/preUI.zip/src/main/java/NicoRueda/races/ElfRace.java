/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.EntityStatType
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier$ModifierTarget
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier$CalculationType
 */
package NicoRueda.races;

import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;
import com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes;
import com.hypixel.hytale.server.core.modules.entitystats.asset.EntityStatType;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier;

public class ElfRace
implements RaceDefinition {
    @Override
    public String id() {
        return "elf";
    }

    @Override
    public String displayName() {
        return "Elfo";
    }

    @Override
    public String tagline() {
        return "\u00c1gil e incansable, se mueve como el viento.";
    }

    @Override
    public void applyStats(EntityStatMap stats, String modifierKey) {
        int manaId = DefaultEntityStatTypes.getMana();
        int speedId = this.getSpeedStatId();
        StaticModifier manaBonus = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.ADDITIVE, 50.0f);
        stats.putModifier(manaId, modifierKey, (Modifier)manaBonus);
        stats.addStatValue(manaId, 50.0f);
        if (speedId != -1) {
            StaticModifier speedBonus = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.MULTIPLICATIVE, 0.2f);
            stats.putModifier(speedId, modifierKey, (Modifier)speedBonus);
        }
    }

    @Override
    public void removeStats(EntityStatMap stats, String modifierKey) {
        int manaId = DefaultEntityStatTypes.getMana();
        int speedId = this.getSpeedStatId();
        stats.removeModifier(manaId, modifierKey);
        if (speedId > 0) {
            stats.removeModifier(speedId, modifierKey);
        }
    }

    private int getSpeedStatId() {
        try {
            if (EntityStatType.getAssetMap() != null) {
                int idx = EntityStatType.getAssetMap().getIndex("MovementSpeed");
                return idx > 0 ? idx : -1;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }
}

