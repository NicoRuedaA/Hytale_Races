/*
 * Decompiled with CFR 0.152.
 */
package NicoRueda.races;

import com.hypixel.hytale.logger.HytaleLogger;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;

public final class RaceRegistry {
    private static final HytaleLogger LOGGER = HytaleLogger.forEnclosingClass();
    private static final Map<String, RaceDefinition> RACES = new LinkedHashMap<String, RaceDefinition>();

    private RaceRegistry() {
    }

    public static void register(RaceDefinition race) {
        if (race == null || race.id() == null) {
            return;
        }
        RACES.put(race.id().toLowerCase(), race);
        LOGGER.at(Level.INFO).log("[PlayableRaces] Raza registrada: %s (id: %s)", (Object)race.displayName(), (Object)race.id());
    }

    public static RaceDefinition get(String id) {
        if (id == null) {
            return null;
        }
        return RACES.get(id.toLowerCase());
    }

    public static boolean exists(String id) {
        return id != null && RACES.containsKey(id.toLowerCase());
    }

    public static Collection<RaceDefinition> all() {
        return Collections.unmodifiableCollection(RACES.values());
    }

    public static void clear() {
        RACES.clear();
    }
}

