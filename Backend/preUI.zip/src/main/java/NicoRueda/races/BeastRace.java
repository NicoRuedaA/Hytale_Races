/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.EntityStatType
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier$ModifierTarget
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier$CalculationType
 */
package NicoRueda.races;

import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;
import com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes;
import com.hypixel.hytale.server.core.modules.entitystats.asset.EntityStatType;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier;

public class BeastRace
implements RaceDefinition {
    @Override
    public String id() {
        return "beast";
    }

    @Override
    public String displayName() {
        return "Bestia";
    }

    @Override
    public String tagline() {
        return "Fuerza salvaje y velocidad depredadora. La magia no es su fuerte.";
    }

    @Override
    public void applyStats(EntityStatMap stats, String modifierKey) {
        int manaId = DefaultEntityStatTypes.getMana();
        int speedId = this.getSpeedStatId();
        int attackDamageId = this.getAttackDamageStatId();
        StaticModifier manaPenalty = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.ADDITIVE, -30.0f);
        stats.putModifier(manaId, modifierKey, (Modifier)manaPenalty);
        if (speedId != -1) {
            StaticModifier speedBonus = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.MULTIPLICATIVE, 0.25f);
            stats.putModifier(speedId, modifierKey, (Modifier)speedBonus);
        }
        if (attackDamageId != -1) {
            StaticModifier damageBonus = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.MULTIPLICATIVE, 0.15f);
            stats.putModifier(attackDamageId, modifierKey, (Modifier)damageBonus);
        }
    }

    @Override
    public void removeStats(EntityStatMap stats, String modifierKey) {
        int manaId = DefaultEntityStatTypes.getMana();
        int speedId = this.getSpeedStatId();
        int attackDamageId = this.getAttackDamageStatId();
        stats.removeModifier(manaId, modifierKey);
        if (speedId > 0) {
            stats.removeModifier(speedId, modifierKey);
        }
        if (attackDamageId > 0) {
            stats.removeModifier(attackDamageId, modifierKey);
        }
    }

    private int getSpeedStatId() {
        try {
            if (EntityStatType.getAssetMap() != null) {
                int idx = EntityStatType.getAssetMap().getIndex("MovementSpeed");
                return idx > 0 ? idx : -1;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }

    private int getAttackDamageStatId() {
        try {
            if (EntityStatType.getAssetMap() != null) {
                int idx = EntityStatType.getAssetMap().getIndex("AttackDamage");
                if (idx > 0) {
                    return idx;
                }
                idx = EntityStatType.getAssetMap().getIndex("Damage");
                if (idx > 0) {
                    return idx;
                }
                idx = EntityStatType.getAssetMap().getIndex("MeleeDamage");
                return idx > 0 ? idx : -1;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }
}

