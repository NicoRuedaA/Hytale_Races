/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.EntityStatType
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier$ModifierTarget
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier$CalculationType
 */
package NicoRueda.races;

import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;
import com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes;
import com.hypixel.hytale.server.core.modules.entitystats.asset.EntityStatType;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier;

public class MonsterRace
implements RaceDefinition {
    @Override
    public String id() {
        return "monster";
    }

    @Override
    public String displayName() {
        return "Monstruo";
    }

    @Override
    public String tagline() {
        return "Resistente como una roca, pero lento como una tortuga.";
    }

    @Override
    public void applyStats(EntityStatMap stats, String modifierKey) {
        int healthId = DefaultEntityStatTypes.getHealth();
        int speedId = this.getSpeedStatId();
        int armorId = this.getArmorStatId();
        StaticModifier healthBonus = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.ADDITIVE, 40.0f);
        stats.putModifier(healthId, modifierKey, (Modifier)healthBonus);
        if (armorId != -1) {
            StaticModifier armorBonus = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.ADDITIVE, 5.0f);
            stats.putModifier(armorId, modifierKey, (Modifier)armorBonus);
        }
        if (speedId != -1) {
            StaticModifier speedPenalty = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.MULTIPLICATIVE, -0.2f);
            stats.putModifier(speedId, modifierKey, (Modifier)speedPenalty);
        }
    }

    @Override
    public void removeStats(EntityStatMap stats, String modifierKey) {
        int healthId = DefaultEntityStatTypes.getHealth();
        int speedId = this.getSpeedStatId();
        int armorId = this.getArmorStatId();
        stats.removeModifier(healthId, modifierKey);
        if (speedId > 0) {
            stats.removeModifier(speedId, modifierKey);
        }
        if (armorId > 0) {
            stats.removeModifier(armorId, modifierKey);
        }
    }

    private int getSpeedStatId() {
        try {
            if (EntityStatType.getAssetMap() != null) {
                int idx = EntityStatType.getAssetMap().getIndex("MovementSpeed");
                return idx > 0 ? idx : -1;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }

    private int getArmorStatId() {
        try {
            if (EntityStatType.getAssetMap() != null) {
                int idx = EntityStatType.getAssetMap().getIndex("Armor");
                if (idx > 0) {
                    return idx;
                }
                idx = EntityStatType.getAssetMap().getIndex("Defence");
                if (idx > 0) {
                    return idx;
                }
                idx = EntityStatType.getAssetMap().getIndex("Defense");
                if (idx > 0) {
                    return idx;
                }
                idx = EntityStatType.getAssetMap().getIndex("ArmorValue");
                return idx > 0 ? idx : -1;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }
}

