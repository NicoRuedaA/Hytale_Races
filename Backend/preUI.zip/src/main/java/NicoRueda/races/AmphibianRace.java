/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.EntityStatType
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier$ModifierTarget
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier$CalculationType
 */
package NicoRueda.races;

import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;
import com.hypixel.hytale.server.core.modules.entitystats.asset.EntityStatType;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier;

public class AmphibianRace
implements RaceDefinition {
    @Override
    public String id() {
        return "amphibian";
    }

    @Override
    public String displayName() {
        return "Anfibio";
    }

    @Override
    public String tagline() {
        return "Los oc\u00e9anos son tu hogar. Respira bajo el agua sin l\u00edmites.";
    }

    @Override
    public void applyStats(EntityStatMap stats, String modifierKey) {
        int oxygenId = this.getOxygenStatId();
        int swimSpeedId = this.getSwimSpeedStatId();
        if (oxygenId != -1) {
            StaticModifier oxygenBonus = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.ADDITIVE, 999999.0f);
            stats.putModifier(oxygenId, modifierKey, (Modifier)oxygenBonus);
        }
        if (swimSpeedId != -1) {
            StaticModifier swimSpeedBonus = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.MULTIPLICATIVE, 0.3f);
            stats.putModifier(swimSpeedId, modifierKey, (Modifier)swimSpeedBonus);
        }
    }

    @Override
    public void removeStats(EntityStatMap stats, String modifierKey) {
        int oxygenId = this.getOxygenStatId();
        int swimSpeedId = this.getSwimSpeedStatId();
        if (oxygenId > 0) {
            stats.removeModifier(oxygenId, modifierKey);
        }
        if (swimSpeedId > 0) {
            stats.removeModifier(swimSpeedId, modifierKey);
        }
    }

    private int getOxygenStatId() {
        try {
            if (EntityStatType.getAssetMap() != null) {
                int idx = EntityStatType.getAssetMap().getIndex("Oxygen");
                if (idx > 0) {
                    return idx;
                }
                idx = EntityStatType.getAssetMap().getIndex("Air");
                if (idx > 0) {
                    return idx;
                }
                idx = EntityStatType.getAssetMap().getIndex("Breath");
                if (idx > 0) {
                    return idx;
                }
                idx = EntityStatType.getAssetMap().getIndex("WaterBreathing");
                return idx > 0 ? idx : -1;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }

    private int getSwimSpeedStatId() {
        try {
            if (EntityStatType.getAssetMap() != null) {
                int idx = EntityStatType.getAssetMap().getIndex("SwimSpeed");
                if (idx > 0) {
                    return idx;
                }
                idx = EntityStatType.getAssetMap().getIndex("SwimmingSpeed");
                if (idx > 0) {
                    return idx;
                }
                idx = EntityStatType.getAssetMap().getIndex("WaterSpeed");
                return idx > 0 ? idx : -1;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }
}

