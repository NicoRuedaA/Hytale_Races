/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 */
package NicoRueda.races;

import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;

public class HumanRace
implements RaceDefinition {
    @Override
    public String id() {
        return "human";
    }

    @Override
    public String displayName() {
        return "Humano";
    }

    @Override
    public String tagline() {
        return "El habitante est\u00e1ndar. Sin bonificaciones ni penalizaciones.";
    }

    @Override
    public void applyStats(EntityStatMap stats, String modifierKey) {
    }

    @Override
    public void removeStats(EntityStatMap stats, String modifierKey) {
    }
}

