/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier$ModifierTarget
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier$CalculationType
 */
package NicoRueda.races;

import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;
import com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier;

public class UndeadRace
implements RaceDefinition {
    @Override
    public String id() {
        return "undead";
    }

    @Override
    public String displayName() {
        return "No-muerto";
    }

    @Override
    public String tagline() {
        return "Entre la vida y la muerte. Resistente a la necrosis, d\u00e9bil a la magia.";
    }

    @Override
    public void applyStats(EntityStatMap stats, String modifierKey) {
        int healthId = DefaultEntityStatTypes.getHealth();
        int manaId = DefaultEntityStatTypes.getMana();
        StaticModifier healthBonus = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.ADDITIVE, 10.0f);
        stats.putModifier(healthId, modifierKey, (Modifier)healthBonus);
        StaticModifier manaPenalty = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.ADDITIVE, -10.0f);
        stats.putModifier(manaId, modifierKey, (Modifier)manaPenalty);
    }

    @Override
    public void removeStats(EntityStatMap stats, String modifierKey) {
        int healthId = DefaultEntityStatTypes.getHealth();
        int manaId = DefaultEntityStatTypes.getMana();
        stats.removeModifier(healthId, modifierKey);
        stats.removeModifier(manaId, modifierKey);
    }
}

