/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.component.ArchetypeChunk
 *  com.hypixel.hytale.component.CommandBuffer
 *  com.hypixel.hytale.component.ComponentType
 *  com.hypixel.hytale.component.Store
 *  com.hypixel.hytale.component.dependency.Dependency
 *  com.hypixel.hytale.component.dependency.Order
 *  com.hypixel.hytale.component.dependency.SystemDependency
 *  com.hypixel.hytale.component.query.Query
 *  com.hypixel.hytale.component.system.tick.EntityTickingSystem
 *  com.hypixel.hytale.server.core.asset.type.entityeffect.config.EntityEffect
 *  com.hypixel.hytale.server.core.entity.effect.EffectControllerComponent
 *  com.hypixel.hytale.server.core.entity.entities.Player
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatsSystems$Recalculate
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatsSystems$StatModifyingSystem
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier
 *  com.hypixel.hytale.server.core.universe.world.storage.EntityStore
 *  it.unimi.dsi.fastutil.ints.Int2ObjectMap
 *  it.unimi.dsi.fastutil.ints.Int2ObjectMap$Entry
 *  javax.annotation.Nonnull
 */
package NicoRueda.systems;

import NicoRueda.RaceManager;
import NicoRueda.components.RaceStatTracker;
import com.hypixel.hytale.component.ArchetypeChunk;
import com.hypixel.hytale.component.CommandBuffer;
import com.hypixel.hytale.component.ComponentType;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.component.dependency.Dependency;
import com.hypixel.hytale.component.dependency.Order;
import com.hypixel.hytale.component.dependency.SystemDependency;
import com.hypixel.hytale.component.query.Query;
import com.hypixel.hytale.component.system.tick.EntityTickingSystem;
import com.hypixel.hytale.server.core.asset.type.entityeffect.config.EntityEffect;
import com.hypixel.hytale.server.core.entity.effect.EffectControllerComponent;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;
import com.hypixel.hytale.server.core.modules.entitystats.EntityStatsSystems;
import com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import java.util.Set;
import javax.annotation.Nonnull;

public class UndeadHealingInversionSystem
extends EntityTickingSystem<EntityStore>
implements EntityStatsSystems.StatModifyingSystem {
    private static final Query<EntityStore> QUERY = Query.and((Query[])new Query[]{Player.getComponentType(), EntityStatMap.getComponentType(), EffectControllerComponent.getComponentType()});
    private final ComponentType<EntityStore, RaceStatTracker> trackerType;
    private final Set<Dependency<EntityStore>> dependencies = Set.of(new SystemDependency(Order.AFTER, EntityStatsSystems.Recalculate.class));

    public UndeadHealingInversionSystem(ComponentType<EntityStore, RaceStatTracker> trackerType) {
        this.trackerType = trackerType;
    }

    @Nonnull
    public Query<EntityStore> getQuery() {
        return QUERY;
    }

    @Nonnull
    public Set<Dependency<EntityStore>> getDependencies() {
        return this.dependencies;
    }

    public void tick(float dt, int index, @Nonnull ArchetypeChunk<EntityStore> archetypeChunk, @Nonnull Store<EntityStore> store, @Nonnull CommandBuffer<EntityStore> commandBuffer) {
        Player player = (Player)archetypeChunk.getComponent(index, Player.getComponentType());
        EntityStatMap stats = (EntityStatMap)archetypeChunk.getComponent(index, EntityStatMap.getComponentType());
        EffectControllerComponent effectController = (EffectControllerComponent)archetypeChunk.getComponent(index, EffectControllerComponent.getComponentType());
        if (player == null || stats == null || effectController == null) {
            return;
        }
        String raceId = RaceManager.getPlayerRace(player);
        if (!UndeadHealingInversionSystem.isUndead(raceId)) {
            return;
        }
        RaceStatTracker tracker = (RaceStatTracker)commandBuffer.ensureAndGetComponent(archetypeChunk.getReferenceTo(index), this.trackerType);
        if (tracker == null) {
            return;
        }
        if (tracker.getRespawnGraceTicks() > 0) {
            return;
        }
        int healthId = DefaultEntityStatTypes.getHealth();
        float totalHealingPerTick = 0.0f;
        Int2ObjectMap<?> activeEffects = effectController.getActiveEffects();
        for (Int2ObjectMap.Entry<?> entry : activeEffects.int2ObjectEntrySet()) {
            StaticModifier[] healthModifiers;
            Int2ObjectMap statModifiers;
            int effectIndex = entry.getIntKey();
            EntityEffect entityEffect = (EntityEffect)EntityEffect.getAssetMap().getAsset(effectIndex);
            if (entityEffect == null || (statModifiers = entityEffect.getStatModifiers()) == null || !statModifiers.containsKey(healthId) || (healthModifiers = (StaticModifier[])statModifiers.get(healthId)) == null || healthModifiers.length == 0) continue;
            for (StaticModifier modifier : healthModifiers) {
                if (modifier == null) continue;
                float modifierValue = modifier.getAmount();
                totalHealingPerTick += modifierValue;
            }
        }
        if (totalHealingPerTick > 0.0f) {
            stats.subtractStatValue(healthId, totalHealingPerTick * 2.0f);
        }
    }

    private static boolean isUndead(String raceId) {
        return raceId != null && (raceId.equalsIgnoreCase("undead") || raceId.equalsIgnoreCase("skeleton"));
    }
}

