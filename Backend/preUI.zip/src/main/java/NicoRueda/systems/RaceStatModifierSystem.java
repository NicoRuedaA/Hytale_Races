/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.component.ArchetypeChunk
 *  com.hypixel.hytale.component.CommandBuffer
 *  com.hypixel.hytale.component.ComponentType
 *  com.hypixel.hytale.component.Store
 *  com.hypixel.hytale.component.dependency.Dependency
 *  com.hypixel.hytale.component.dependency.Order
 *  com.hypixel.hytale.component.dependency.SystemDependency
 *  com.hypixel.hytale.component.query.Query
 *  com.hypixel.hytale.component.system.tick.EntityTickingSystem
 *  com.hypixel.hytale.server.core.entity.entities.Player
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatsSystems$Recalculate
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatsSystems$StatModifyingSystem
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.EntityStatType
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier$ModifierTarget
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier
 *  com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier$CalculationType
 *  com.hypixel.hytale.server.core.universe.world.storage.EntityStore
 *  javax.annotation.Nonnull
 */
package NicoRueda.systems;

import NicoRueda.RaceManager;
import NicoRueda.components.RaceStatTracker;
import com.hypixel.hytale.component.ArchetypeChunk;
import com.hypixel.hytale.component.CommandBuffer;
import com.hypixel.hytale.component.ComponentType;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.component.dependency.Dependency;
import com.hypixel.hytale.component.dependency.Order;
import com.hypixel.hytale.component.dependency.SystemDependency;
import com.hypixel.hytale.component.query.Query;
import com.hypixel.hytale.component.system.tick.EntityTickingSystem;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;
import com.hypixel.hytale.server.core.modules.entitystats.EntityStatsSystems;
import com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes;
import com.hypixel.hytale.server.core.modules.entitystats.asset.EntityStatType;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.Modifier;
import com.hypixel.hytale.server.core.modules.entitystats.modifier.StaticModifier;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import java.util.Set;
import javax.annotation.Nonnull;

public class RaceStatModifierSystem
extends EntityTickingSystem<EntityStore>
implements EntityStatsSystems.StatModifyingSystem {
    private static final String BEAST_SPEED_MODIFIER_KEY = "playableraces_beast_dynamic_speed";
    private static final float BEAST_BASE_SPEED_BONUS = 0.05f;
    private static final float BEAST_MISSING_HEALTH_SPEED_BONUS = 0.2f;
    private static final float BEAST_STAMINA_DRAIN_MULTIPLIER = 1.5f;
    private static final Query<EntityStore> QUERY = Query.and((Query[])new Query[]{Player.getComponentType(), EntityStatMap.getComponentType()});
    private final ComponentType<EntityStore, RaceStatTracker> trackerType;
    private final Set<Dependency<EntityStore>> dependencies = Set.of(new SystemDependency(Order.AFTER, EntityStatsSystems.Recalculate.class));

    public RaceStatModifierSystem(ComponentType<EntityStore, RaceStatTracker> trackerType) {
        this.trackerType = trackerType;
    }

    @Nonnull
    public Query<EntityStore> getQuery() {
        return QUERY;
    }

    @Nonnull
    public Set<Dependency<EntityStore>> getDependencies() {
        return this.dependencies;
    }

    public void tick(float dt, int index, @Nonnull ArchetypeChunk<EntityStore> archetypeChunk, @Nonnull Store<EntityStore> store, @Nonnull CommandBuffer<EntityStore> commandBuffer) {
        float currentStamina;
        Player player = (Player)archetypeChunk.getComponent(index, Player.getComponentType());
        EntityStatMap stats = (EntityStatMap)archetypeChunk.getComponent(index, EntityStatMap.getComponentType());
        if (player == null || stats == null) {
            return;
        }
        String raceId = RaceManager.getPlayerRace(player);
        if (raceId == null) {
            return;
        }
        RaceStatTracker tracker = (RaceStatTracker)commandBuffer.ensureAndGetComponent(archetypeChunk.getReferenceTo(index), this.trackerType);
        if (tracker == null) {
            return;
        }
        int healthId = DefaultEntityStatTypes.getHealth();
        int manaId = DefaultEntityStatTypes.getMana();
        int staminaId = DefaultEntityStatTypes.getStamina();
        int speedId = RaceStatModifierSystem.getSpeedStatId();
        float currentHealth = stats.get(healthId) != null ? stats.get(healthId).get() : -1.0f;
        float currentMana = stats.get(manaId) != null ? stats.get(manaId).get() : -1.0f;
        float f = currentStamina = stats.get(staminaId) != null ? stats.get(staminaId).get() : -1.0f;
        if (tracker.getLastHealth() < 0.0f) {
            tracker.setLastHealth(currentHealth);
            tracker.setLastMana(currentMana);
            tracker.setLastStamina(currentStamina);
            return;
        }
        float deltaHealth = currentHealth - tracker.getLastHealth();
        float deltaMana = currentMana - tracker.getLastMana();
        float deltaStamina = currentStamina - tracker.getLastStamina();
        if (tracker.getLastHealth() >= 0.0f && tracker.getLastHealth() < 20.0f && deltaHealth > 50.0f) {
            tracker.setRespawnGraceTicks(40);
        }
        tracker.decrementRespawnGrace();
        if (raceId.equalsIgnoreCase("beast")) {
            RaceStatModifierSystem.handleBeastSpeed(stats, healthId, speedId, currentHealth);
            RaceStatModifierSystem.handleBeastStaminaDrain(stats, staminaId, deltaStamina);
        } else if (speedId > 0) {
            stats.removeModifier(speedId, BEAST_SPEED_MODIFIER_KEY);
        }
        tracker.setLastHealth(stats.get(healthId) != null ? stats.get(healthId).get() : currentHealth);
        if (!raceId.equalsIgnoreCase("eldritch")) {
            tracker.setLastMana(stats.get(manaId) != null ? stats.get(manaId).get() : currentMana);
        }
        tracker.setLastStamina(stats.get(staminaId) != null ? stats.get(staminaId).get() : currentStamina);
    }

    private static boolean isUndead(String raceId) {
        return raceId.equalsIgnoreCase("undead") || raceId.equalsIgnoreCase("skeleton");
    }

    private static void handleBeastSpeed(EntityStatMap stats, int healthId, int speedId, float currentHealth) {
        if (speedId <= 0) {
            return;
        }
        if (stats.get(healthId) == null) {
            return;
        }
        float maxHealth = stats.get(healthId).getMax();
        if (maxHealth <= 0.0f) {
            return;
        }
        float missingPct = 1.0f - currentHealth / maxHealth;
        if (missingPct < 0.0f) {
            missingPct = 0.0f;
        } else if (missingPct > 1.0f) {
            missingPct = 1.0f;
        }
        float totalBonus = 0.05f + 0.2f * missingPct;
        StaticModifier speedBonus = new StaticModifier(Modifier.ModifierTarget.MAX, StaticModifier.CalculationType.MULTIPLICATIVE, totalBonus);
        stats.putModifier(speedId, BEAST_SPEED_MODIFIER_KEY, (Modifier)speedBonus);
    }

    private static void handleBeastStaminaDrain(EntityStatMap stats, int staminaId, float deltaStamina) {
        if (staminaId <= 0 || deltaStamina >= 0.0f) {
            return;
        }
        float extraDrain = -deltaStamina * 0.5f;
        if (extraDrain > 0.0f) {
            stats.subtractStatValue(staminaId, extraDrain);
        }
    }

    private static int getSpeedStatId() {
        try {
            if (EntityStatType.getAssetMap() != null) {
                int idx = EntityStatType.getAssetMap().getIndex("MovementSpeed");
                return idx > 0 ? idx : -1;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return -1;
    }
}

