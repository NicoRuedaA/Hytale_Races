/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.component.ArchetypeChunk
 *  com.hypixel.hytale.component.CommandBuffer
 *  com.hypixel.hytale.component.ComponentType
 *  com.hypixel.hytale.component.Store
 *  com.hypixel.hytale.component.dependency.Dependency
 *  com.hypixel.hytale.component.dependency.Order
 *  com.hypixel.hytale.component.dependency.SystemDependency
 *  com.hypixel.hytale.component.query.Query
 *  com.hypixel.hytale.component.system.tick.EntityTickingSystem
 *  com.hypixel.hytale.server.core.entity.entities.Player
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatsSystems$Recalculate
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatsSystems$StatModifyingSystem
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes
 *  com.hypixel.hytale.server.core.universe.world.storage.EntityStore
 *  javax.annotation.Nonnull
 */
package NicoRueda.systems;

import NicoRueda.components.RaceData;
import NicoRueda.components.RaceStatTracker;
import com.hypixel.hytale.component.ArchetypeChunk;
import com.hypixel.hytale.component.CommandBuffer;
import com.hypixel.hytale.component.ComponentType;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.component.dependency.Dependency;
import com.hypixel.hytale.component.dependency.Order;
import com.hypixel.hytale.component.dependency.SystemDependency;
import com.hypixel.hytale.component.query.Query;
import com.hypixel.hytale.component.system.tick.EntityTickingSystem;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;
import com.hypixel.hytale.server.core.modules.entitystats.EntityStatsSystems;
import com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import java.util.Set;
import javax.annotation.Nonnull;

public class EldritchManaInterceptionSystem
extends EntityTickingSystem<EntityStore>
implements EntityStatsSystems.StatModifyingSystem {
    private final ComponentType<EntityStore, RaceData> raceDataType;
    private final ComponentType<EntityStore, RaceStatTracker> trackerType;
    private final Set<Dependency<EntityStore>> dependencies = Set.of(new SystemDependency(Order.AFTER, EntityStatsSystems.Recalculate.class));

    public EldritchManaInterceptionSystem(ComponentType<EntityStore, RaceData> raceDataType, ComponentType<EntityStore, RaceStatTracker> trackerType) {
        this.raceDataType = raceDataType;
        this.trackerType = trackerType;
    }

    @Nonnull
    public Query<EntityStore> getQuery() {
        return Query.and((Query[])new Query[]{Player.getComponentType(), EntityStatMap.getComponentType(), this.raceDataType, this.trackerType});
    }

    @Nonnull
    public Set<Dependency<EntityStore>> getDependencies() {
        return this.dependencies;
    }

    public void tick(float dt, int index, @Nonnull ArchetypeChunk<EntityStore> archetypeChunk, @Nonnull Store<EntityStore> store, @Nonnull CommandBuffer<EntityStore> commandBuffer) {
        Player player = (Player)archetypeChunk.getComponent(index, Player.getComponentType());
        EntityStatMap stats = (EntityStatMap)archetypeChunk.getComponent(index, EntityStatMap.getComponentType());
        RaceData raceData = (RaceData)archetypeChunk.getComponent(index, this.raceDataType);
        if (player == null || stats == null || raceData == null || !raceData.hasRace()) {
            return;
        }
        if (!"eldritch".equals(raceData.getSelectedRace())) {
            return;
        }
        RaceStatTracker tracker = (RaceStatTracker)commandBuffer.ensureAndGetComponent(archetypeChunk.getReferenceTo(index), this.trackerType);
        if (tracker == null) {
            return;
        }
        int manaId = DefaultEntityStatTypes.getMana();
        int healthId = DefaultEntityStatTypes.getHealth();
        float currentMana = stats.get(manaId) != null ? stats.get(manaId).get() : 0.0f;
        float maxMana = stats.get(manaId) != null ? stats.get(manaId).getMax() : 0.0f;
        float lastMana = tracker.getLastMana();
        if (lastMana < 0.0f) {
            tracker.setLastMana(maxMana);
            if (currentMana < maxMana) {
                stats.setStatValue(manaId, maxMana);
            }
            return;
        }
        float manaSpent = lastMana - currentMana;
        if (manaSpent > 0.0f) {
            stats.subtractStatValue(healthId, manaSpent);
        }
        if (currentMana < maxMana) {
            stats.setStatValue(manaId, maxMana);
        }
        tracker.setLastMana(maxMana);
    }
}

