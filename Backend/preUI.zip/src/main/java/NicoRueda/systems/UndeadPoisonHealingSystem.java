/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.component.ArchetypeChunk
 *  com.hypixel.hytale.component.CommandBuffer
 *  com.hypixel.hytale.component.ComponentType
 *  com.hypixel.hytale.component.Store
 *  com.hypixel.hytale.component.SystemGroup
 *  com.hypixel.hytale.component.query.Query
 *  com.hypixel.hytale.server.core.entity.entities.Player
 *  com.hypixel.hytale.server.core.modules.entity.damage.Damage
 *  com.hypixel.hytale.server.core.modules.entity.damage.DamageCause
 *  com.hypixel.hytale.server.core.modules.entity.damage.DamageEventSystem
 *  com.hypixel.hytale.server.core.modules.entity.damage.DamageModule
 *  com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap
 *  com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes
 *  com.hypixel.hytale.server.core.universe.world.storage.EntityStore
 *  javax.annotation.Nonnull
 *  javax.annotation.Nullable
 */
package NicoRueda.systems;

import NicoRueda.RaceManager;
import NicoRueda.components.RaceStatTracker;
import com.hypixel.hytale.component.ArchetypeChunk;
import com.hypixel.hytale.component.CommandBuffer;
import com.hypixel.hytale.component.ComponentType;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.component.SystemGroup;
import com.hypixel.hytale.component.query.Query;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.modules.entity.damage.Damage;
import com.hypixel.hytale.server.core.modules.entity.damage.DamageCause;
import com.hypixel.hytale.server.core.modules.entity.damage.DamageEventSystem;
import com.hypixel.hytale.server.core.modules.entity.damage.DamageModule;
import com.hypixel.hytale.server.core.modules.entitystats.EntityStatMap;
import com.hypixel.hytale.server.core.modules.entitystats.asset.DefaultEntityStatTypes;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class UndeadPoisonHealingSystem
extends DamageEventSystem {
    private final ComponentType<EntityStore, RaceStatTracker> trackerType = RaceStatTracker.getComponentType();
    private static final Query<EntityStore> QUERY = Query.and((Query[])new Query[]{Player.getComponentType(), EntityStatMap.getComponentType()});

    @Nullable
    public SystemGroup<EntityStore> getGroup() {
        return DamageModule.get().getFilterDamageGroup();
    }

    @Nonnull
    public Query<EntityStore> getQuery() {
        return QUERY;
    }

    public void handle(int index, @Nonnull ArchetypeChunk<EntityStore> archetypeChunk, @Nonnull Store<EntityStore> store, @Nonnull CommandBuffer<EntityStore> commandBuffer, @Nonnull Damage damage) {
        RaceStatTracker tracker;
        DamageCause damageCause = (DamageCause)DamageCause.getAssetMap().getAsset(damage.getDamageCauseIndex());
        if (damageCause == null || damageCause.getId() == null || !damageCause.getId().equalsIgnoreCase("Poison")) {
            return;
        }
        Player player = (Player)archetypeChunk.getComponent(index, Player.getComponentType());
        EntityStatMap stats = (EntityStatMap)archetypeChunk.getComponent(index, EntityStatMap.getComponentType());
        if (player == null || stats == null) {
            return;
        }
        String raceId = RaceManager.getPlayerRace(player);
        if (raceId == null) {
            return;
        }
        if (!raceId.equalsIgnoreCase("undead") && !raceId.equalsIgnoreCase("skeleton")) {
            return;
        }
        float poisonAmount = damage.getAmount();
        if (poisonAmount <= 0.0f) {
            return;
        }
        damage.setCancelled(true);
        stats.addStatValue(DefaultEntityStatTypes.getHealth(), poisonAmount);
        if (this.trackerType != null && (tracker = (RaceStatTracker)commandBuffer.ensureAndGetComponent(archetypeChunk.getReferenceTo(index), this.trackerType)) != null) {
            tracker.addPendingPoisonHeal(poisonAmount);
        }
    }
}

