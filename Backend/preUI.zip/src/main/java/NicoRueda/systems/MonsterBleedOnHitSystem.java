/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.component.ArchetypeChunk
 *  com.hypixel.hytale.component.CommandBuffer
 *  com.hypixel.hytale.component.Ref
 *  com.hypixel.hytale.component.Store
 *  com.hypixel.hytale.component.SystemGroup
 *  com.hypixel.hytale.component.query.Query
 *  com.hypixel.hytale.server.core.asset.type.entityeffect.config.EntityEffect
 *  com.hypixel.hytale.server.core.entity.effect.EffectControllerComponent
 *  com.hypixel.hytale.server.core.entity.entities.Player
 *  com.hypixel.hytale.server.core.modules.entity.damage.Damage
 *  com.hypixel.hytale.server.core.modules.entity.damage.Damage$EntitySource
 *  com.hypixel.hytale.server.core.modules.entity.damage.Damage$Source
 *  com.hypixel.hytale.server.core.modules.entity.damage.DamageEventSystem
 *  com.hypixel.hytale.server.core.modules.entity.damage.DamageModule
 *  com.hypixel.hytale.server.core.universe.world.storage.EntityStore
 *  javax.annotation.Nonnull
 *  javax.annotation.Nullable
 */
package NicoRueda.systems;

import NicoRueda.RaceManager;
import com.hypixel.hytale.component.ArchetypeChunk;
import com.hypixel.hytale.component.CommandBuffer;
import com.hypixel.hytale.component.Ref;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.component.SystemGroup;
import com.hypixel.hytale.component.query.Query;
import com.hypixel.hytale.server.core.asset.type.entityeffect.config.EntityEffect;
import com.hypixel.hytale.server.core.entity.effect.EffectControllerComponent;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.modules.entity.damage.Damage;
import com.hypixel.hytale.server.core.modules.entity.damage.DamageEventSystem;
import com.hypixel.hytale.server.core.modules.entity.damage.DamageModule;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class MonsterBleedOnHitSystem
extends DamageEventSystem {
    private static final String BLEED_EFFECT_ID = "Bleed";
    private static final Query<EntityStore> QUERY = Query.and((Query[])new Query[]{EffectControllerComponent.getComponentType()});

    @Nullable
    public SystemGroup<EntityStore> getGroup() {
        return DamageModule.get().getInspectDamageGroup();
    }

    @Nonnull
    public Query<EntityStore> getQuery() {
        return QUERY;
    }

    public void handle(int index, @Nonnull ArchetypeChunk<EntityStore> archetypeChunk, @Nonnull Store<EntityStore> store, @Nonnull CommandBuffer<EntityStore> commandBuffer, @Nonnull Damage damage) {
        if (damage.isCancelled() || damage.getAmount() <= 0.0f) {
            return;
        }
        Damage.Source source = damage.getSource();
        if (!(source instanceof Damage.EntitySource)) {
            return;
        }
        Damage.EntitySource entitySource = (Damage.EntitySource)source;
        Ref sourceRef = entitySource.getRef();
        if (sourceRef == null || !sourceRef.isValid()) {
            return;
        }
        Player attacker = (Player)store.getComponent(sourceRef, Player.getComponentType());
        if (attacker == null) {
            return;
        }
        String raceId = RaceManager.getPlayerRace(attacker);
        if (raceId == null || !raceId.equalsIgnoreCase("monster")) {
            return;
        }
        Ref targetRef = archetypeChunk.getReferenceTo(index);
        if (targetRef == null || !targetRef.isValid()) {
            return;
        }
        if (sourceRef.getIndex() == targetRef.getIndex()) {
            return;
        }
        EffectControllerComponent effectController = (EffectControllerComponent)commandBuffer.getComponent(targetRef, EffectControllerComponent.getComponentType());
        if (effectController == null) {
            return;
        }
        EntityEffect bleedEffect = (EntityEffect)EntityEffect.getAssetMap().getAsset(BLEED_EFFECT_ID);
        if (bleedEffect == null) {
            return;
        }
        effectController.addEffect(targetRef, bleedEffect, commandBuffer);
    }
}

