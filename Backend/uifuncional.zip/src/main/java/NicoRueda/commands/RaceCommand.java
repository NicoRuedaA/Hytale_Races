/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.hypixel.hytale.component.Ref
 *  com.hypixel.hytale.component.Store
 *  com.hypixel.hytale.server.core.command.system.CommandContext
 *  com.hypixel.hytale.server.core.command.system.arguments.system.RequiredArg
 *  com.hypixel.hytale.server.core.command.system.arguments.types.ArgTypes
 *  com.hypixel.hytale.server.core.command.system.arguments.types.ArgumentType
 *  com.hypixel.hytale.server.core.command.system.basecommands.AbstractPlayerCommand
 *  com.hypixel.hytale.server.core.entity.entities.Player
 *  com.hypixel.hytale.server.core.universe.PlayerRef
 *  com.hypixel.hytale.server.core.universe.world.World
 *  com.hypixel.hytale.server.core.universe.world.storage.EntityStore
 *  javax.annotation.Nonnull
 */
package NicoRueda.commands;

import NicoRueda.RaceManager;
import NicoRueda.races.RaceDefinition;
import NicoRueda.races.RaceRegistry;
import NicoRueda.ui.RaceEmptyPage;

import com.hypixel.hytale.component.Ref;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.server.core.Message;
import com.hypixel.hytale.server.core.command.system.CommandContext;
import com.hypixel.hytale.server.core.command.system.arguments.system.RequiredArg;
import com.hypixel.hytale.server.core.command.system.arguments.types.ArgTypes;
import com.hypixel.hytale.server.core.command.system.arguments.types.ArgumentType;
import com.hypixel.hytale.server.core.command.system.basecommands.AbstractPlayerCommand;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import com.hypixel.hytale.server.core.universe.world.World;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import java.util.stream.Collectors;
import javax.annotation.Nonnull;

public final class RaceCommand {
    private RaceCommand() {
    }

    private static String listRaceIds() {
        return RaceRegistry.all().stream().map(RaceDefinition::id).collect(Collectors.joining(", "));
    }

    public static class ListSubCommand
            extends AbstractPlayerCommand {
        public ListSubCommand() {
            super("list", "Lista las razas disponibles");
        }

        protected boolean canGeneratePermission() {
            return false;
        }

        protected void execute(@Nonnull CommandContext ctx, @Nonnull Store<EntityStore> store,
                @Nonnull Ref<EntityStore> ref, @Nonnull PlayerRef playerRef, @Nonnull World world) {
            ctx.sendMessage(Message.raw("Razas disponibles:"));
            for (RaceDefinition race : RaceRegistry.all()) {
                ctx.sendMessage(Message.raw("- " + race.displayName() + " (" + race.id() + ")"));
                ctx.sendMessage(Message.raw("  " + race.tagline()));
            }
        }
    }

    public static class ResetSubCommand
            extends AbstractPlayerCommand {
        public ResetSubCommand() {
            super("reset", "Borra tu raza actual");
        }

        protected boolean canGeneratePermission() {
            return false;
        }

        protected void execute(@Nonnull CommandContext ctx, @Nonnull Store<EntityStore> store,
                @Nonnull Ref<EntityStore> ref, @Nonnull PlayerRef playerRef, @Nonnull World world) {
            Player player = (Player) store.getComponent(ref, Player.getComponentType());
            if (player == null) {
                ctx.sendMessage(Message.raw("No se pudo acceder al jugador."));
                return;
            }
            if (!RaceManager.hasRace(player)) {
                ctx.sendMessage(Message.raw("No tienes una raza seleccionada."));
                return;
            }
            RaceManager.resetRace(player);
            ctx.sendMessage(Message.raw("Tu raza fue reiniciada."));
        }
    }

    public static class InfoRaceSubCommand
            extends AbstractPlayerCommand {
        public InfoRaceSubCommand() {
            super("info", "Muestra tu raza actual");
        }

        protected boolean canGeneratePermission() {
            return false;
        }

        protected void execute(@Nonnull CommandContext ctx, @Nonnull Store<EntityStore> store,
                @Nonnull Ref<EntityStore> ref, @Nonnull PlayerRef playerRef, @Nonnull World world) {
            Player player = (Player) store.getComponent(ref, Player.getComponentType());
            if (player == null) {
                ctx.sendMessage(Message.raw("No se pudo acceder al jugador."));
                return;
            }
            String raceId = RaceManager.getPlayerRace(player);
            if (raceId == null) {
                ctx.sendMessage(Message.raw("No tienes raza seleccionada."));
                ctx.sendMessage(Message.raw("Usa /race list para ver razas disponibles."));
                return;
            }
            RaceDefinition race = RaceRegistry.get(raceId);
            ctx.sendMessage(Message.raw("Tu raza actual: " + race.displayName()));
            ctx.sendMessage(Message.raw(race.tagline()));
        }
    }

    public static class ChangeSubCommand
            extends AbstractPlayerCommand {
        private final RequiredArg<String> raceArg = this.withRequiredArg("raza",
                "Raza a elegir: " + RaceCommand.listRaceIds(), (ArgumentType) ArgTypes.STRING);

        public ChangeSubCommand() {
            super("change", "Elige tu raza");
        }

        protected boolean canGeneratePermission() {
            return false;
        }

        protected void execute(@Nonnull CommandContext ctx, @Nonnull Store<EntityStore> store,
                @Nonnull Ref<EntityStore> ref, @Nonnull PlayerRef playerRef, @Nonnull World world) {
            String raceId;
            String input = (String) this.raceArg.get(ctx);
            String string = raceId = input != null ? input.toLowerCase() : null;
            if (!RaceRegistry.exists(raceId)) {
                ctx.sendMessage(Message.raw("Raza inválida: " + (input != null ? input : "")));
                ctx.sendMessage(Message.raw("Razas disponibles: " + RaceCommand.listRaceIds()));
                return;
            }
            Player player = (Player) store.getComponent(ref, Player.getComponentType());
            if (player == null) {
                ctx.sendMessage(Message.raw("No se pudo acceder al jugador."));
                return;
            }
            String currentRace = RaceManager.getPlayerRace(player);
            if (raceId.equals(currentRace)) {
                ctx.sendMessage(Message.raw("Ya tienes esa raza: " + RaceRegistry.get(raceId).displayName()));
                return;
            }
            RaceManager.selectRace(player, raceId);
            RaceDefinition race = RaceRegistry.get(raceId);
            ctx.sendMessage(Message.raw("Raza actualizada correctamente."));
            ctx.sendMessage(Message.raw("Nueva raza: " + race.displayName()));
            ctx.sendMessage(Message.raw(race.tagline()));
            if (currentRace != null) {
                ctx.sendMessage(Message.raw("Raza anterior: " + RaceRegistry.get(currentRace).displayName()));
            }
        }
    }

    public static class UiSubCommand
            extends AbstractPlayerCommand {
        public UiSubCommand() {
            super("ui", "Abre la interfaz de selección de raza");
        }

        protected boolean canGeneratePermission() {
            return false;
        }

        protected void execute(@Nonnull CommandContext ctx, @Nonnull Store<EntityStore> store,
                @Nonnull Ref<EntityStore> ref, @Nonnull PlayerRef playerRef, @Nonnull World world) {
            Player player = (Player) store.getComponent(ref, Player.getComponentType());
            if (player == null) {
                ctx.sendMessage(Message.raw("No se pudo acceder al jugador."));
                return;
            }
            player.getPageManager().openCustomPage(ref, store, new RaceEmptyPage(playerRef));
        }
    }

}
