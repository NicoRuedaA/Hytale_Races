package NicoRueda.ui;

import NicoRueda.RaceManager;
import NicoRueda.races.RaceDefinition;
import NicoRueda.races.RaceRegistry;
import com.hypixel.hytale.component.Ref;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.protocol.packets.interface_.Page;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.entity.entities.player.pages.choices.ChoiceBasePage;
import com.hypixel.hytale.server.core.entity.entities.player.pages.choices.ChoiceElement;
import com.hypixel.hytale.server.core.entity.entities.player.pages.choices.ChoiceInteraction;
import com.hypixel.hytale.server.core.ui.Value;
import com.hypixel.hytale.server.core.ui.builder.EventData;
import com.hypixel.hytale.server.core.ui.builder.UICommandBuilder;
import com.hypixel.hytale.server.core.ui.builder.UIEventBuilder;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nonnull;

public class RaceEmptyPage extends ChoiceBasePage {
    private static final Value<String> BUTTON_SELECTED_STYLE = Value.ref("Pages/BasicTextButton.ui", "SelectedLabelStyle");

    public RaceEmptyPage(@Nonnull PlayerRef playerRef) {
        super(playerRef, buildElements(), "Pages/ItemRepairPage.ui");
    }

    @Override
    public void build(@Nonnull Ref<EntityStore> ref, @Nonnull UICommandBuilder commandBuilder,
            @Nonnull UIEventBuilder eventBuilder, @Nonnull Store<EntityStore> store) {
        ChoiceElement[] elements = getElements();
        if (elements.length == 0) {
            commandBuilder.append(getPageLayout());
            commandBuilder.clear("#ElementList");
            commandBuilder.append("#ElementList", "Pages/BasicTextButton.ui");
            commandBuilder.set("#ElementList[0].Text", "No races available");
            eventBuilder.addEventBinding(
                    com.hypixel.hytale.protocol.packets.interface_.CustomUIEventBindingType.Activating,
                    "#ElementList[0]",
                    EventData.of("Index", "-1"),
                    false);
            return;
        }

        super.build(ref, commandBuilder, eventBuilder, store);

        Player player = store.getComponent(ref, Player.getComponentType());
        String currentRaceId = player != null ? RaceManager.getPlayerRace(player) : null;
        if (currentRaceId == null) {
            return;
        }

        for (int i = 0; i < elements.length; i++) {
            if (elements[i] instanceof RaceChoiceElement raceElement && raceElement.matchesRace(currentRaceId)) {
                commandBuilder.set("#ElementList[" + i + "].Style", BUTTON_SELECTED_STYLE);
            }
        }
    }

    @Override
    public void handleDataEvent(@Nonnull Ref<EntityStore> ref, @Nonnull Store<EntityStore> store,
            @Nonnull ChoiceBasePage.ChoicePageEventData data) {
        if (data.getIndex() < 0) {
            return;
        }
        super.handleDataEvent(ref, store, data);
    }

    @Nonnull
    private static ChoiceElement[] buildElements() {
        List<ChoiceElement> elements = new ArrayList<>();
        for (RaceDefinition race : RaceRegistry.all()) {
            elements.add(new RaceChoiceElement(race));
        }
        return elements.toArray(ChoiceElement[]::new);
    }

    private static class RaceChoiceElement extends ChoiceElement {
        private final String raceId;
        private final String buttonText;

        RaceChoiceElement(@Nonnull RaceDefinition race) {
            this.raceId = race.id();
            this.buttonText = race.displayName() + " - " + race.tagline();
            this.interactions = new ChoiceInteraction[] { new SelectRaceInteraction(race.id()) };
        }

        @Override
        public void addButton(UICommandBuilder commandBuilder, UIEventBuilder eventBuilder, String selector, PlayerRef playerRef) {
            commandBuilder.append("#ElementList", "Pages/BasicTextButton.ui");
            commandBuilder.set(selector + ".Text", this.buttonText);
        }

        boolean matchesRace(@Nonnull String selectedRaceId) {
            return this.raceId.equalsIgnoreCase(selectedRaceId);
        }
    }

    private static class SelectRaceInteraction extends ChoiceInteraction {
        private final String raceId;

        SelectRaceInteraction(@Nonnull String raceId) {
            this.raceId = raceId;
        }

        @Override
        public void run(@Nonnull Store<EntityStore> store, @Nonnull Ref<EntityStore> ref, @Nonnull PlayerRef playerRef) {
            Player player = store.getComponent(ref, Player.getComponentType());
            if (player == null) {
                return;
            }

            RaceManager.selectRace(player, this.raceId);
            player.getPageManager().setPage(ref, store, Page.None);
        }
    }
}
